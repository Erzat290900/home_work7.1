package com.company;

public interface HavingSuperAbility {
    String applySuperType(String superAbilityType);
}
