package com.company;

public class Magic extends Hero  {

    @Override
    public String applySuperType(String superAbilityType) {
        return "Magic применил суперспособность "+ superAbilityType;
    }
}
